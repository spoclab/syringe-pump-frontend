﻿namespace product762
{
    partial class frmGlobalSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdOk = new System.Windows.Forms.Button();
            this.chkSyringe1 = new System.Windows.Forms.CheckBox();
            this.chkSyringe2 = new System.Windows.Forms.CheckBox();
            this.chkSyringe3 = new System.Windows.Forms.CheckBox();
            this.chkSyringe4 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmdOk
            // 
            this.cmdOk.Location = new System.Drawing.Point(362, 86);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(64, 24);
            this.cmdOk.TabIndex = 0;
            this.cmdOk.Text = "OK";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // chkSyringe1
            // 
            this.chkSyringe1.AutoSize = true;
            this.chkSyringe1.Location = new System.Drawing.Point(6, 35);
            this.chkSyringe1.Name = "chkSyringe1";
            this.chkSyringe1.Size = new System.Drawing.Size(92, 17);
            this.chkSyringe1.TabIndex = 1;
            this.chkSyringe1.Text = "SYRINGE001";
            this.chkSyringe1.UseVisualStyleBackColor = true;
            this.chkSyringe1.CheckStateChanged += new System.EventHandler(this.chkSyringe1_CheckStateChanged);
            // 
            // chkSyringe2
            // 
            this.chkSyringe2.AutoSize = true;
            this.chkSyringe2.Location = new System.Drawing.Point(104, 35);
            this.chkSyringe2.Name = "chkSyringe2";
            this.chkSyringe2.Size = new System.Drawing.Size(92, 17);
            this.chkSyringe2.TabIndex = 2;
            this.chkSyringe2.Text = "SYRINGE002";
            this.chkSyringe2.UseVisualStyleBackColor = true;
            this.chkSyringe2.CheckStateChanged += new System.EventHandler(this.chkSyringe2_CheckStateChanged);
            // 
            // chkSyringe3
            // 
            this.chkSyringe3.AutoSize = true;
            this.chkSyringe3.Location = new System.Drawing.Point(202, 35);
            this.chkSyringe3.Name = "chkSyringe3";
            this.chkSyringe3.Size = new System.Drawing.Size(92, 17);
            this.chkSyringe3.TabIndex = 3;
            this.chkSyringe3.Text = "SYRINGE003";
            this.chkSyringe3.UseVisualStyleBackColor = true;
            this.chkSyringe3.CheckStateChanged += new System.EventHandler(this.chkSyringe3_CheckStateChanged);
            // 
            // chkSyringe4
            // 
            this.chkSyringe4.AutoSize = true;
            this.chkSyringe4.Location = new System.Drawing.Point(300, 35);
            this.chkSyringe4.Name = "chkSyringe4";
            this.chkSyringe4.Size = new System.Drawing.Size(92, 17);
            this.chkSyringe4.TabIndex = 4;
            this.chkSyringe4.Text = "SYRINGE004";
            this.chkSyringe4.UseVisualStyleBackColor = true;
            this.chkSyringe4.CheckStateChanged += new System.EventHandler(this.chkSyringe4_CheckStateChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkSyringe1);
            this.groupBox1.Controls.Add(this.chkSyringe4);
            this.groupBox1.Controls.Add(this.chkSyringe2);
            this.groupBox1.Controls.Add(this.chkSyringe3);
            this.groupBox1.Location = new System.Drawing.Point(13, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(413, 70);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DEFAULT BITS FOR COUNTERCLOCKWISE ROTATION";
            // 
            // frmGlobalSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 120);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmdOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmGlobalSettings";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GLOABL SETTINGS";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.CheckBox chkSyringe1;
        private System.Windows.Forms.CheckBox chkSyringe2;
        private System.Windows.Forms.CheckBox chkSyringe3;
        private System.Windows.Forms.CheckBox chkSyringe4;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}