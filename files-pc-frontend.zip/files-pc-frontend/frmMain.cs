﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Globalization;
using System.Diagnostics;

namespace product762
{
    public partial class frmMain : Form
    {
        private frmAbout instFrmAbout = null;
        private frmGlobalSettings instFrmGlobalSettings = null;
        Thread comThread = null; // communications thread
        private frmSyringesSettings instFrmSyringesSettings = null; // syringe settings form 
        private SerialPort comPort = null;
        private byte directionFlags = 0; // 0 is out (= rotate right) 1 is in (= rotate left)
        private double[] maxULPerMin = new double[4];
        private double[] curULPerMin = new double[4];
        private double[] curStepFreqs = new double[4];
        String[] curValueOldText = new String[4]; // for double value validation
        int[] curValueCaretIndexes = new int[4]; // for double value validation

        // application wide settings
        public void loadSettings()
        {
            if (this.instFrmSyringesSettings == null)
            {
                this.instFrmSyringesSettings = new frmSyringesSettings();
            }
            this.instFrmSyringesSettings.loadSettings();
            if (this.instFrmGlobalSettings == null)
            {
                this.instFrmGlobalSettings = new frmGlobalSettings();
            }
            this.instFrmGlobalSettings.loadSettings();            
        }
        public void saveSettings()
        {
            this.instFrmSyringesSettings.saveSettings();
            this.instFrmGlobalSettings.saveSettings();
        }
        // adopt maximum uL/min values and the track bar ticks
        public void adjustTrackBars()
        {
            uint counter = 0;
            TrackBar[] allTrackBars = { this.tbrSyringe1, this.tbrSyringe2, this.tbrSyringe3, this.tbrSyringe4 };
            TextBox[] allCurValueTextBoxes = { this.txtCurValue1, this.txtCurValue2, this.txtCurValue3, this.txtCurValue4 };
            foreach (Label maxLabel in new Label[] { this.lblMax1, this.lblMax2, this.lblMax3, this.lblMax4 }) // loop all labels and adjust the maximum uL/min value
            {
                maxULPerMin[counter] = (60.0 * Math.PI * this.instFrmSyringesSettings.diameters[counter] * this.instFrmSyringesSettings.diameters[counter] * this.instFrmSyringesSettings.movPerRev[counter] * Constants.maxStepFreq) / (4.0 * this.instFrmSyringesSettings.stepsPerRev[counter]);
                maxLabel.Text = maxULPerMin[counter].ToString("0.00", new CultureInfo("en-US")) + " µL/min";
                allTrackBars[counter].Value = 0; // reset the track bar
                allCurValueTextBoxes[counter].Text = "0"; // reset the current value
                counter++;
            }
        }
        // calculate the step frequency
        public void calcFrequency(int number)
        {
            Label[] allLblFreqs = { this.lblFreq1, this.lblFreq2, this.lblFreq3, this.lblFreq4 };
            curStepFreqs[number] = (4.0 * this.instFrmSyringesSettings.stepsPerRev[number] * curULPerMin[number])/(60.0 * Math.PI * this.instFrmSyringesSettings.diameters[number] * this.instFrmSyringesSettings.diameters[number] * this.instFrmSyringesSettings.movPerRev[number]);
            allLblFreqs[number].Text = curStepFreqs[number].ToString("G17", new CultureInfo("en-US")) + " Hz";
        }
        // serial communications
        public void doComPortListing()
        {
            string detailedName;
            SerialPort currentSerialPort = null;
            System.Windows.Forms.ToolStripItem currentItem = null;
            string[] portNames = SerialPort.GetPortNames();
            this.oPENToolStripMenuItem.DropDownItems.Clear(); // delete all present items
            foreach (string portName in portNames)
            {
                currentSerialPort = new SerialPort(portName);
                //detailedName = portName + " [BAUD:" + currentSerialPort.BaudRate + " PARITY:" + currentSerialPort.Parity + " STOPBITS:" + currentSerialPort.StopBits + " DATABITS:" + currentSerialPort.DataBits + " HANDSHAKE:" + currentSerialPort.Handshake + " FLOWCTRL:" + currentSerialPort.RtsEnable + " TIMEOUT(R/W):" + currentSerialPort.ReadTimeout + "/" + currentSerialPort.WriteTimeout + "]";
                detailedName = portName + " [" + currentSerialPort.BaudRate + "|" + currentSerialPort.Parity + "|" + currentSerialPort.StopBits + "|" + currentSerialPort.DataBits + "|" + currentSerialPort.Handshake + "|" + currentSerialPort.RtsEnable + "|" + currentSerialPort.ReadTimeout + "|" + currentSerialPort.WriteTimeout + "] ";
                currentItem = this.oPENToolStripMenuItem.DropDownItems.Add(detailedName);
                currentItem.Click += delegate(object sender, System.EventArgs e) { openSerialPort(sender, e, portName); };
            }
        }
        private void openSerialPort(object sender, System.EventArgs e, string portName) // event handler called by the COM submenu entries
        {
            if (this.comPort == null)
            {
                this.comPort = new SerialPort(portName);
            }
            this.comPort.Open();
            if (comPort.IsOpen)
            {
                oPENToolStripMenuItem.Enabled = false; // the line is open, disable the open com tool menu item
                cLOSEToolStripMenuItem.Enabled = true; // enable close com & send tool menu item
                sENDToolStripMenuItem.Enabled = true;
                cmdSend.Enabled = true;
                this.appendStatusLine(System.String.Format("{0} is open ...", portName));
            }
            else
            {
                this.appendStatusLine(System.String.Format("unable to open {0} ...", portName));
            }
        }
        private void comThreadFunc() // communications thread function
        {
            Stopwatch stw = null;
            byte[] msgBytes = new byte[33];
            byte[] dblBytes = new byte[8];
            bool gotRecvOkByte = false;            
            appendStatusLine("dispatched communications thread ...");            
            for (uint i = 0; i < 4; i++) // append floating points
            {
                dblBytes = BitConverter.GetBytes(curStepFreqs[i]);
                for (uint j = 0; j < 8; j++)
                {
                    msgBytes[i * 8 + j] = dblBytes[j];
                }
            }
            msgBytes[32] = (byte)(directionFlags ^ this.instFrmGlobalSettings.rotCntClockwiseMask); // append direction flags with default counter clock rotation
            try
            {
                comPort.Write(msgBytes, 0, 33);
                stw = Stopwatch.StartNew();
                while ((stw.ElapsedMilliseconds < Constants.timeOutUSecs) && !gotRecvOkByte)
                {
                    if (comPort.BytesToRead > 0)
                    {
                        if ((byte)comPort.ReadByte() == Constants.recvOK)
                        {
                            gotRecvOkByte = true;
                        }
                    }
                }
                if (gotRecvOkByte)
                {
                    appendStatusLine("sent data, thread exited ...");
                    MethodInvoker delegateSetAllLedColors = delegate
                    {
                        setAllLedColors();
                    };
                    BeginInvoke(delegateSetAllLedColors);
                }
                else
                {
                    appendStatusLine("COMMUNICATIONS ERROR, RESTART TEENSY AND THIS PROGRAM ...");
                }
                cmdSend.BeginInvoke((Action)delegate() { cmdSend.Enabled = true; });
                MethodInvoker delegateEnableMenuItemSend = delegate
                {
                    enableMenuItemSend();
                };
                BeginInvoke(delegateEnableMenuItemSend);
                stw.Stop();
            }
            catch (Exception e)
            {
                appendStatusLine("COMMUNICATIONS ERROR: \"" + e.Message + "\", is the cable unplugged?");
            }
        }
        private void enableMenuItemSend()
        {
            sENDToolStripMenuItem.Enabled = true;
        }
        private void closeSerialPort()
        {
            this.comPort.Close();
            oPENToolStripMenuItem.Enabled = true; // enable open tool menu item
            cLOSEToolStripMenuItem.Enabled = false; // disable close & send menu item
            sENDToolStripMenuItem.Enabled = false;
            if (!this.comPort.IsOpen)
            {
                this.appendStatusLine(String.Format("closed {0} ...", this.comPort.PortName)); // normal operation
            }
            else
            {
                this.appendStatusLine(String.Format("all com ports are already closed ...")); // it was not open
            }
        }
        // write to status message
        private void appendStatusLine(System.String text)
        {
            if (this.txtOutput.InvokeRequired)
            {
                this.Invoke(new System.Action<string>(appendStatusLine), new object[] { text });
                return;
            }
            if (txtOutput.Text == string.Empty) // there is no text -> no new line delimiter needed
            {
                txtOutput.AppendText("[" + System.DateTime.Now.ToString("HH:mm:ss") + "] " + text);
            }
            else // there already is text -> put a new line characters in front ...
            {
                txtOutput.AppendText(System.Environment.NewLine + "[" + System.DateTime.Now.ToString("HH:mm:ss") + "] " + text);
            }
        }
        // set LED colors from thread
        private void setAllLedColors()
        {
            Microsoft.VisualBasic.PowerPacks.OvalShape[] allLeds = { ledSyringe1, ledSyringe2, ledSyringe3, ledSyringe4 };
            for (uint i = 0; i < 4; i++)
            {
                if (curStepFreqs[i] == 0.0) allLeds[i].FillColor = Color.Black;
                else allLeds[i].FillColor = Color.Yellow;
            }
        }

        // ALL FORM DESIGNER EVENTS
        public frmMain()
        {
            InitializeComponent();
        }
        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((comThread != null) && (comThread.IsAlive == true)) comThread.Abort();
            Application.Exit();
        }
        private void sYRINGESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.instFrmSyringesSettings.ShowDialog();
            adjustTrackBars();
        }
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if ((comThread != null) && (comThread.IsAlive == true)) comThread.Abort();
            saveSettings();
        }
        private void cLOSEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((comThread != null) && (comThread.IsAlive == true)) comThread.Abort();
            closeSerialPort();
        }       
        private void cmdDir1_Click(object sender, EventArgs e)
        {
            if (this.cmdDir1.Text == "OUT")
            {
                this.directionFlags |= 8; // set ???? 1???
                this.cmdDir1.Text = "IN";
            }
            else if(this.cmdDir1.Text == "IN")
            {
                this.directionFlags &= 7; // set ???? 0???
                this.cmdDir1.Text = "OUT";
            }
            appendStatusLine("direction flags changed to " + Convert.ToString((byte)(directionFlags ^ this.instFrmGlobalSettings.rotCntClockwiseMask), 2).PadLeft(8, '0') + " ...");
        }
        private void cmdDir2_Click(object sender, EventArgs e)
        {
            if (this.cmdDir2.Text == "OUT")
            {
                this.directionFlags |= 4; // set ???? ?1??
                this.cmdDir2.Text = "IN";
            }
            else if (this.cmdDir2.Text == "IN")
            {
                this.directionFlags &= 11; // set ???? ?0??
                this.cmdDir2.Text = "OUT";
            }
            appendStatusLine("direction flags changed to " + Convert.ToString((byte)(directionFlags ^ this.instFrmGlobalSettings.rotCntClockwiseMask), 2).PadLeft(8, '0') + " ...");
        }
        private void cmdDir3_Click(object sender, EventArgs e)
        {
            if (this.cmdDir3.Text == "OUT")
            {
                this.directionFlags |= 2; // set ???? ??1?
                this.cmdDir3.Text = "IN";
            }
            else if (this.cmdDir3.Text == "IN")
            {
                this.directionFlags &= 13; // set ???? ??0?
                this.cmdDir3.Text = "OUT";
            }
            appendStatusLine("direction flags changed to " + Convert.ToString((byte)(directionFlags ^ this.instFrmGlobalSettings.rotCntClockwiseMask), 2).PadLeft(8, '0') + " ...");
        }
        private void cmdDir4_Click(object sender, EventArgs e)
        {
            if (this.cmdDir4.Text == "OUT")
            {
                this.directionFlags |= 1; // set ???? ???1
                this.cmdDir4.Text = "IN";
            }
            else if (this.cmdDir4.Text == "IN")
            {
                this.directionFlags &= 14; // set ???? ????0
                this.cmdDir4.Text = "OUT";
            }
            appendStatusLine("direction flags changed to " + Convert.ToString((byte)(directionFlags ^ this.instFrmGlobalSettings.rotCntClockwiseMask), 2).PadLeft(8, '0') + " ...");
        }
        private void txtCurValue1_TextChanged(object sender, EventArgs e)
        {
            double doubleValue;
            if (txtCurValue1.Text == "") // reset "" to zero
            {
                txtCurValue1.Text = "0";
            }
            if (!Double.TryParse(txtCurValue1.Text, NumberStyles.Number, new CultureInfo("en-US"), out doubleValue) || (doubleValue < 0) || (doubleValue > maxULPerMin[0]))
            {
                txtCurValue1.TextChanged -= txtCurValue1_TextChanged; // the next line changes the text, prevent calling this event handler in an endless loop
                txtCurValue1.Text = curValueOldText[0];
                txtCurValue1.SelectionStart = curValueCaretIndexes[0];
                txtCurValue1.TextChanged += txtCurValue1_TextChanged;
            }
            else
            {
                curULPerMin[0] = doubleValue;
            }            
            tbrSyringe1.ValueChanged -= tbrSyringe1_ValueChanged;
            tbrSyringe1.Value = (int)Math.Round((curULPerMin[0] / maxULPerMin[0]) * tbrSyringe1.Maximum, 0);
            tbrSyringe1.ValueChanged += tbrSyringe1_ValueChanged;
            calcFrequency(0);
            ledSyringe1.FillColor = Color.Red; // always go to status not yet sent
        }
        private void txtCurValue1_KeyDown(object sender, KeyEventArgs e)
        {
            curValueOldText[0] = txtCurValue1.Text;
            curValueCaretIndexes[0] = txtCurValue1.SelectionStart;
        }
        private void txtCurValue2_TextChanged(object sender, EventArgs e)
        {
            double doubleValue;
            if (txtCurValue2.Text == "") // reset "" to zero
            {
                txtCurValue2.Text = "0";
            }
            if (!Double.TryParse(txtCurValue2.Text, NumberStyles.Number, new CultureInfo("en-US"), out doubleValue) || (doubleValue < 0) || (doubleValue > maxULPerMin[1]))
            {
                txtCurValue2.TextChanged -= txtCurValue2_TextChanged; // the next line changes the text, prevent calling this event handler in an endless loop
                txtCurValue2.Text = curValueOldText[1];
                txtCurValue2.SelectionStart = curValueCaretIndexes[1];
                txtCurValue2.TextChanged += txtCurValue2_TextChanged;
            }
            else
            {
                curULPerMin[1] = doubleValue;
            }
            tbrSyringe2.ValueChanged -= tbrSyringe2_ValueChanged;
            tbrSyringe2.Value = (int)Math.Round((curULPerMin[1] / maxULPerMin[1]) * tbrSyringe2.Maximum, 0);
            tbrSyringe2.ValueChanged += tbrSyringe2_ValueChanged;
            calcFrequency(1);
            ledSyringe2.FillColor = Color.Red; // always go to status not yet sent
        }
        private void txtCurValue2_KeyDown(object sender, KeyEventArgs e)
        {
            curValueOldText[1] = txtCurValue2.Text;
            curValueCaretIndexes[1] = txtCurValue2.SelectionStart;
        }
        private void txtCurValue3_TextChanged(object sender, EventArgs e)
        {
            double doubleValue;
            if (txtCurValue3.Text == "") // reset "" to zero
            {
                txtCurValue3.Text = "0";
            }
            if (!Double.TryParse(txtCurValue3.Text, NumberStyles.Number, new CultureInfo("en-US"), out doubleValue) || (doubleValue < 0) || (doubleValue > maxULPerMin[2]))
            {
                txtCurValue3.TextChanged -= txtCurValue3_TextChanged; // the next line changes the text, prevent calling this event handler in an endless loop
                txtCurValue3.Text = curValueOldText[2];
                txtCurValue3.SelectionStart = curValueCaretIndexes[2];
                txtCurValue3.TextChanged += txtCurValue3_TextChanged;
            }
            else
            {
                curULPerMin[2] = doubleValue;
            }
            tbrSyringe3.ValueChanged -= tbrSyringe3_ValueChanged;
            tbrSyringe3.Value = (int)Math.Round((curULPerMin[2] / maxULPerMin[2]) * tbrSyringe3.Maximum, 0);
            tbrSyringe3.ValueChanged += tbrSyringe3_ValueChanged;
            calcFrequency(2);
            ledSyringe3.FillColor = Color.Red; // always go to status not yet sent
        }
        private void txtCurValue3_KeyDown(object sender, KeyEventArgs e)
        {
            curValueOldText[2] = txtCurValue3.Text;
            curValueCaretIndexes[2] = txtCurValue3.SelectionStart;
        }
        private void txtCurValue4_TextChanged(object sender, EventArgs e)
        {
            double doubleValue;
            if (txtCurValue4.Text == "") // reset "" to zero
            {
                txtCurValue4.Text = "0";
            }
            if (!Double.TryParse(txtCurValue4.Text, NumberStyles.Number, new CultureInfo("en-US"), out doubleValue) || (doubleValue < 0) || (doubleValue > maxULPerMin[3]))
            {
                txtCurValue4.TextChanged -= txtCurValue4_TextChanged; // the next line changes the text, prevent calling this event handler in an endless loop
                txtCurValue4.Text = curValueOldText[3];
                txtCurValue4.SelectionStart = curValueCaretIndexes[3];
                txtCurValue4.TextChanged += txtCurValue4_TextChanged;
            }
            else
            {
                curULPerMin[3] = doubleValue;
            }
            tbrSyringe4.ValueChanged -= tbrSyringe3_ValueChanged;
            tbrSyringe4.Value = (int)Math.Round((curULPerMin[3] / maxULPerMin[3]) * tbrSyringe4.Maximum, 0);
            tbrSyringe4.ValueChanged += tbrSyringe3_ValueChanged;
            calcFrequency(3);
            ledSyringe4.FillColor = Color.Red; // always go to status not yet sent
        }
        private void txtCurValue4_KeyDown(object sender, KeyEventArgs e)
        {
            curValueOldText[3] = txtCurValue4.Text;
            curValueCaretIndexes[3] = txtCurValue4.SelectionStart;
        }
        private void tbrSyringe1_ValueChanged(object sender, EventArgs e)
        {
            double uLPerMin;
            uLPerMin = ((double)tbrSyringe1.Value / (double)tbrSyringe1.Maximum) * maxULPerMin[0];
            txtCurValue1.Text = uLPerMin.ToString("G17", new CultureInfo("en-US"));
        }
        private void tbrSyringe2_ValueChanged(object sender, EventArgs e)
        {
            double uLPerMin;
            uLPerMin = ((double)tbrSyringe2.Value / (double)tbrSyringe2.Maximum) * maxULPerMin[1];
            txtCurValue2.Text = uLPerMin.ToString("G17", new CultureInfo("en-US"));
        }
        private void tbrSyringe3_ValueChanged(object sender, EventArgs e)
        {
            double uLPerMin;
            uLPerMin = ((double)tbrSyringe3.Value / (double)tbrSyringe3.Maximum) * maxULPerMin[2];
            txtCurValue3.Text = uLPerMin.ToString("G17", new CultureInfo("en-US"));
        }
        private void tbrSyringe4_ValueChanged(object sender, EventArgs e)
        {
            double uLPerMin;
            uLPerMin = ((double)tbrSyringe4.Value / (double)tbrSyringe4.Maximum) * maxULPerMin[3];
            txtCurValue4.Text = uLPerMin.ToString("G17", new CultureInfo("en-US"));
        }
        private void sENDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((comThread != null) && (comThread.IsAlive == true)) comThread.Abort();
            comThread = new Thread(comThreadFunc); // clear previous contents
            cmdSend.Enabled = false;
            sENDToolStripMenuItem.Enabled = false;
            comThread.Start(); // start the thread
        }
        private void aBOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (instFrmAbout == null) instFrmAbout = new frmAbout();
            instFrmAbout.about.Text = Properties.Resources.strAbout;
            instFrmAbout.about.SelectionStart = 0;
            instFrmAbout.about.SelectionLength = 0;
            instFrmAbout.ShowDialog();
        }
        private void rESCANBUSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            doComPortListing();
        }
        private void cmdSend_Click(object sender, EventArgs e)
        {
            sENDToolStripMenuItem_Click(sender, e);
        }
        private void gLOBALSETTINGSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.instFrmGlobalSettings.ShowDialog();
        }
    }
}
