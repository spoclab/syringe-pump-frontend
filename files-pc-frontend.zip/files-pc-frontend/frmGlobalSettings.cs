﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace product762
{
    public partial class frmGlobalSettings : Form
    {
        public byte rotCntClockwiseMask = 0; // 0000 0000
        public frmGlobalSettings()
        {
            InitializeComponent();
        }
        public void loadSettings()
        {
            this.chkSyringe1.Checked = Properties.Settings.Default.rotCntClockwise1;
            this.chkSyringe2.Checked = Properties.Settings.Default.rotCntClockwise2;
            this.chkSyringe3.Checked = Properties.Settings.Default.rotCntClockwise3;
            this.chkSyringe4.Checked = Properties.Settings.Default.rotCntClockwise4;
            if (this.chkSyringe1.Checked) rotCntClockwiseMask |= 8;
            if (this.chkSyringe2.Checked) rotCntClockwiseMask |= 4;
            if (this.chkSyringe3.Checked) rotCntClockwiseMask |= 2;
            if (this.chkSyringe4.Checked) rotCntClockwiseMask |= 1;
        }
        public void saveSettings()
        {
            Properties.Settings.Default.rotCntClockwise1 = this.chkSyringe1.Checked;
            Properties.Settings.Default.rotCntClockwise2 = this.chkSyringe2.Checked;
            Properties.Settings.Default.rotCntClockwise3 = this.chkSyringe3.Checked;
            Properties.Settings.Default.rotCntClockwise4 = this.chkSyringe4.Checked;
            Properties.Settings.Default.Save();
        }
        private void cmdOk_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void chkSyringe1_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkSyringe1.Checked)
            {
                rotCntClockwiseMask |= 8;
            }
            else
            {
                rotCntClockwiseMask &= 7;
            }
        }
        private void chkSyringe2_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkSyringe2.Checked)
            {
                rotCntClockwiseMask |= 4;
            }
            else
            {
                rotCntClockwiseMask &= 11;
            }
        }
        private void chkSyringe3_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkSyringe3.Checked)
            {
                rotCntClockwiseMask |= 2;
            }
            else
            {
                rotCntClockwiseMask &= 13;
            }

        }
        private void chkSyringe4_CheckStateChanged(object sender, EventArgs e)
        {
            if (chkSyringe3.Checked)
            {
                rotCntClockwiseMask |= 1;
            }
            else
            {
                rotCntClockwiseMask &= 14;
            }
        }
    }
}
