﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

static class Constants
{
    public const double minMovPerRev = 0.001; // minium screw movment per revolution in mm
    public const double maxMovPerRev = 1; // maximum screw movment per revolution in mm
    public const double minDiameter = 3; // minium syringe diameter in mm
    public const double maxDiameter = 30; // maximum syringe diameter in mm
    public const int minStepsPerRev = 1; // minimum steps per rev
    public const int maxStepsPerRev = 10000; // maximum steps per rev
    public const double minStepFreq = 0; // minimum stepping frequency in Hz
    public const double maxStepFreq = 50; // maximum stepping frequency in Hz
    public const byte recvOK = 42; // receive ok byte
    public const int timeOutUSecs = 5000;
}

namespace product762
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            frmMain instFrmMain = new frmMain();
            instFrmMain.loadSettings();
            instFrmMain.adjustTrackBars();
            instFrmMain.doComPortListing();
            Application.Run(instFrmMain);
        }
    }
}
