﻿using System.Windows.Forms;

namespace product762
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fILEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rESCANBUSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oPENToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cLOSEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.sENDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eDITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sYRINGESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.gLOBALSETTINGSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hELPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aBOUTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.tbrSyringe1 = new System.Windows.Forms.TrackBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblFreq1 = new System.Windows.Forms.Label();
            this.lblCur1 = new System.Windows.Forms.Label();
            this.txtCurValue1 = new System.Windows.Forms.TextBox();
            this.lblMax1 = new System.Windows.Forms.Label();
            this.lblMin1 = new System.Windows.Forms.Label();
            this.cmdDir1 = new System.Windows.Forms.Button();
            this.shapeContainer3 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ledSyringe1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.tbrSyringe2 = new System.Windows.Forms.TrackBar();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblFreq2 = new System.Windows.Forms.Label();
            this.lblCur2 = new System.Windows.Forms.Label();
            this.txtCurValue2 = new System.Windows.Forms.TextBox();
            this.lblMax2 = new System.Windows.Forms.Label();
            this.cmdDir2 = new System.Windows.Forms.Button();
            this.lblMin2 = new System.Windows.Forms.Label();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ledSyringe2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblFreq3 = new System.Windows.Forms.Label();
            this.lblCur3 = new System.Windows.Forms.Label();
            this.txtCurValue3 = new System.Windows.Forms.TextBox();
            this.lblMax3 = new System.Windows.Forms.Label();
            this.cmdDir3 = new System.Windows.Forms.Button();
            this.lblMin3 = new System.Windows.Forms.Label();
            this.tbrSyringe3 = new System.Windows.Forms.TrackBar();
            this.shapeContainer4 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ledSyringe3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblFreq4 = new System.Windows.Forms.Label();
            this.lblCur4 = new System.Windows.Forms.Label();
            this.txtCurValue4 = new System.Windows.Forms.TextBox();
            this.lblMax4 = new System.Windows.Forms.Label();
            this.cmdDir4 = new System.Windows.Forms.Button();
            this.lblMin4 = new System.Windows.Forms.Label();
            this.tbrSyringe4 = new System.Windows.Forms.TrackBar();
            this.shapeContainer5 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ledSyringe4 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cmdSend = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ovalShape3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ovalShape1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe2)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe3)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe4)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fILEToolStripMenuItem,
            this.eDITToolStripMenuItem,
            this.hELPToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fILEToolStripMenuItem
            // 
            this.fILEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rESCANBUSToolStripMenuItem,
            this.oPENToolStripMenuItem,
            this.cLOSEToolStripMenuItem,
            this.toolStripSeparator3,
            this.sENDToolStripMenuItem,
            this.toolStripSeparator1,
            this.eXITToolStripMenuItem});
            this.fILEToolStripMenuItem.Name = "fILEToolStripMenuItem";
            this.fILEToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.fILEToolStripMenuItem.Text = "FILE";
            // 
            // rESCANBUSToolStripMenuItem
            // 
            this.rESCANBUSToolStripMenuItem.Name = "rESCANBUSToolStripMenuItem";
            this.rESCANBUSToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.rESCANBUSToolStripMenuItem.Text = "RESCAN BUS";
            this.rESCANBUSToolStripMenuItem.Click += new System.EventHandler(this.rESCANBUSToolStripMenuItem_Click);
            // 
            // oPENToolStripMenuItem
            // 
            this.oPENToolStripMenuItem.Name = "oPENToolStripMenuItem";
            this.oPENToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.oPENToolStripMenuItem.Text = "OPEN COM";
            // 
            // cLOSEToolStripMenuItem
            // 
            this.cLOSEToolStripMenuItem.Enabled = false;
            this.cLOSEToolStripMenuItem.Name = "cLOSEToolStripMenuItem";
            this.cLOSEToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.cLOSEToolStripMenuItem.Text = "CLOSE COM";
            this.cLOSEToolStripMenuItem.Click += new System.EventHandler(this.cLOSEToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(139, 6);
            // 
            // sENDToolStripMenuItem
            // 
            this.sENDToolStripMenuItem.Enabled = false;
            this.sENDToolStripMenuItem.Name = "sENDToolStripMenuItem";
            this.sENDToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.sENDToolStripMenuItem.Text = "SEND STATE";
            this.sENDToolStripMenuItem.Click += new System.EventHandler(this.sENDToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(139, 6);
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.eXITToolStripMenuItem.Text = "EXIT";
            this.eXITToolStripMenuItem.Click += new System.EventHandler(this.eXITToolStripMenuItem_Click);
            // 
            // eDITToolStripMenuItem
            // 
            this.eDITToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sYRINGESToolStripMenuItem,
            this.toolStripSeparator2,
            this.gLOBALSETTINGSToolStripMenuItem});
            this.eDITToolStripMenuItem.Name = "eDITToolStripMenuItem";
            this.eDITToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.eDITToolStripMenuItem.Text = "EDIT";
            // 
            // sYRINGESToolStripMenuItem
            // 
            this.sYRINGESToolStripMenuItem.Name = "sYRINGESToolStripMenuItem";
            this.sYRINGESToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.sYRINGESToolStripMenuItem.Text = "SYRINGES SETTINGS";
            this.sYRINGESToolStripMenuItem.Click += new System.EventHandler(this.sYRINGESToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(178, 6);
            // 
            // gLOBALSETTINGSToolStripMenuItem
            // 
            this.gLOBALSETTINGSToolStripMenuItem.Name = "gLOBALSETTINGSToolStripMenuItem";
            this.gLOBALSETTINGSToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.gLOBALSETTINGSToolStripMenuItem.Text = "GLOBAL SETTINGS";
            this.gLOBALSETTINGSToolStripMenuItem.Click += new System.EventHandler(this.gLOBALSETTINGSToolStripMenuItem_Click);
            // 
            // hELPToolStripMenuItem
            // 
            this.hELPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aBOUTToolStripMenuItem});
            this.hELPToolStripMenuItem.Name = "hELPToolStripMenuItem";
            this.hELPToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.hELPToolStripMenuItem.Text = "HELP";
            // 
            // aBOUTToolStripMenuItem
            // 
            this.aBOUTToolStripMenuItem.Name = "aBOUTToolStripMenuItem";
            this.aBOUTToolStripMenuItem.Size = new System.Drawing.Size(113, 22);
            this.aBOUTToolStripMenuItem.Text = "ABOUT";
            this.aBOUTToolStripMenuItem.Click += new System.EventHandler(this.aBOUTToolStripMenuItem_Click);
            // 
            // txtOutput
            // 
            this.txtOutput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutput.Location = new System.Drawing.Point(12, 517);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOutput.Size = new System.Drawing.Size(760, 82);
            this.txtOutput.TabIndex = 2;
            // 
            // tbrSyringe1
            // 
            this.tbrSyringe1.Location = new System.Drawing.Point(6, 19);
            this.tbrSyringe1.Maximum = 100;
            this.tbrSyringe1.Name = "tbrSyringe1";
            this.tbrSyringe1.Size = new System.Drawing.Size(408, 45);
            this.tbrSyringe1.TabIndex = 3;
            this.tbrSyringe1.ValueChanged += new System.EventHandler(this.tbrSyringe1_ValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.CausesValidation = false;
            this.groupBox1.Controls.Add(this.lblFreq1);
            this.groupBox1.Controls.Add(this.lblCur1);
            this.groupBox1.Controls.Add(this.txtCurValue1);
            this.groupBox1.Controls.Add(this.lblMax1);
            this.groupBox1.Controls.Add(this.lblMin1);
            this.groupBox1.Controls.Add(this.cmdDir1);
            this.groupBox1.Controls.Add(this.tbrSyringe1);
            this.groupBox1.Controls.Add(this.shapeContainer3);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(760, 100);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SYRINGE001";
            // 
            // lblFreq1
            // 
            this.lblFreq1.AutoSize = true;
            this.lblFreq1.Location = new System.Drawing.Point(469, 41);
            this.lblFreq1.Name = "lblFreq1";
            this.lblFreq1.Size = new System.Drawing.Size(29, 13);
            this.lblFreq1.TabIndex = 9;
            this.lblFreq1.Text = "0 Hz";
            // 
            // lblCur1
            // 
            this.lblCur1.AutoSize = true;
            this.lblCur1.Location = new System.Drawing.Point(686, 21);
            this.lblCur1.Name = "lblCur1";
            this.lblCur1.Size = new System.Drawing.Size(40, 13);
            this.lblCur1.TabIndex = 8;
            this.lblCur1.Text = "µL/min";
            // 
            // txtCurValue1
            // 
            this.txtCurValue1.Location = new System.Drawing.Point(472, 18);
            this.txtCurValue1.Name = "txtCurValue1";
            this.txtCurValue1.Size = new System.Drawing.Size(208, 20);
            this.txtCurValue1.TabIndex = 7;
            this.txtCurValue1.Text = "0";
            this.txtCurValue1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCurValue1.TextChanged += new System.EventHandler(this.txtCurValue1_TextChanged);
            this.txtCurValue1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCurValue1_KeyDown);
            // 
            // lblMax1
            // 
            this.lblMax1.AutoSize = true;
            this.lblMax1.Location = new System.Drawing.Point(384, 67);
            this.lblMax1.Name = "lblMax1";
            this.lblMax1.Size = new System.Drawing.Size(43, 13);
            this.lblMax1.TabIndex = 6;
            this.lblMax1.Text = "lblMax1";
            // 
            // lblMin1
            // 
            this.lblMin1.AutoSize = true;
            this.lblMin1.Location = new System.Drawing.Point(11, 67);
            this.lblMin1.Name = "lblMin1";
            this.lblMin1.Size = new System.Drawing.Size(64, 13);
            this.lblMin1.TabIndex = 5;
            this.lblMin1.Text = "0.00 µL/min";
            // 
            // cmdDir1
            // 
            this.cmdDir1.Location = new System.Drawing.Point(472, 70);
            this.cmdDir1.Name = "cmdDir1";
            this.cmdDir1.Size = new System.Drawing.Size(64, 24);
            this.cmdDir1.TabIndex = 4;
            this.cmdDir1.Text = "OUT";
            this.cmdDir1.UseVisualStyleBackColor = true;
            this.cmdDir1.Click += new System.EventHandler(this.cmdDir1_Click);
            // 
            // shapeContainer3
            // 
            this.shapeContainer3.Location = new System.Drawing.Point(3, 16);
            this.shapeContainer3.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer3.Name = "shapeContainer3";
            this.shapeContainer3.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ledSyringe1});
            this.shapeContainer3.Size = new System.Drawing.Size(754, 81);
            this.shapeContainer3.TabIndex = 10;
            this.shapeContainer3.TabStop = false;
            // 
            // ledSyringe1
            // 
            this.ledSyringe1.BackColor = System.Drawing.Color.Transparent;
            this.ledSyringe1.FillColor = System.Drawing.Color.Red;
            this.ledSyringe1.FillGradientColor = System.Drawing.Color.Transparent;
            this.ledSyringe1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ledSyringe1.Location = new System.Drawing.Point(730, 60);
            this.ledSyringe1.Name = "ledSyringe1";
            this.ledSyringe1.Size = new System.Drawing.Size(16, 16);
            // 
            // tbrSyringe2
            // 
            this.tbrSyringe2.Location = new System.Drawing.Point(6, 19);
            this.tbrSyringe2.Maximum = 100;
            this.tbrSyringe2.Name = "tbrSyringe2";
            this.tbrSyringe2.Size = new System.Drawing.Size(408, 45);
            this.tbrSyringe2.TabIndex = 3;
            this.tbrSyringe2.ValueChanged += new System.EventHandler(this.tbrSyringe2_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblFreq2);
            this.groupBox2.Controls.Add(this.lblCur2);
            this.groupBox2.Controls.Add(this.txtCurValue2);
            this.groupBox2.Controls.Add(this.lblMax2);
            this.groupBox2.Controls.Add(this.cmdDir2);
            this.groupBox2.Controls.Add(this.lblMin2);
            this.groupBox2.Controls.Add(this.tbrSyringe2);
            this.groupBox2.Controls.Add(this.shapeContainer2);
            this.groupBox2.Location = new System.Drawing.Point(12, 133);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(760, 100);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SYRINGE002";
            // 
            // lblFreq2
            // 
            this.lblFreq2.AutoSize = true;
            this.lblFreq2.Location = new System.Drawing.Point(469, 45);
            this.lblFreq2.Name = "lblFreq2";
            this.lblFreq2.Size = new System.Drawing.Size(29, 13);
            this.lblFreq2.TabIndex = 10;
            this.lblFreq2.Text = "0 Hz";
            // 
            // lblCur2
            // 
            this.lblCur2.AutoSize = true;
            this.lblCur2.Location = new System.Drawing.Point(686, 25);
            this.lblCur2.Name = "lblCur2";
            this.lblCur2.Size = new System.Drawing.Size(40, 13);
            this.lblCur2.TabIndex = 9;
            this.lblCur2.Text = "µL/min";
            // 
            // txtCurValue2
            // 
            this.txtCurValue2.Location = new System.Drawing.Point(472, 22);
            this.txtCurValue2.Name = "txtCurValue2";
            this.txtCurValue2.Size = new System.Drawing.Size(208, 20);
            this.txtCurValue2.TabIndex = 8;
            this.txtCurValue2.Text = "0";
            this.txtCurValue2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCurValue2.TextChanged += new System.EventHandler(this.txtCurValue2_TextChanged);
            this.txtCurValue2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCurValue2_KeyDown);
            // 
            // lblMax2
            // 
            this.lblMax2.AutoSize = true;
            this.lblMax2.Location = new System.Drawing.Point(384, 67);
            this.lblMax2.Name = "lblMax2";
            this.lblMax2.Size = new System.Drawing.Size(43, 13);
            this.lblMax2.TabIndex = 8;
            this.lblMax2.Text = "lblMax2";
            // 
            // cmdDir2
            // 
            this.cmdDir2.Location = new System.Drawing.Point(472, 70);
            this.cmdDir2.Name = "cmdDir2";
            this.cmdDir2.Size = new System.Drawing.Size(64, 24);
            this.cmdDir2.TabIndex = 5;
            this.cmdDir2.Text = "OUT";
            this.cmdDir2.UseVisualStyleBackColor = true;
            this.cmdDir2.Click += new System.EventHandler(this.cmdDir2_Click);
            // 
            // lblMin2
            // 
            this.lblMin2.AutoSize = true;
            this.lblMin2.Cursor = System.Windows.Forms.Cursors.Default;
            this.lblMin2.Location = new System.Drawing.Point(11, 67);
            this.lblMin2.Name = "lblMin2";
            this.lblMin2.Size = new System.Drawing.Size(64, 13);
            this.lblMin2.TabIndex = 7;
            this.lblMin2.Text = "0.00 µL/min";
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(3, 16);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ledSyringe2});
            this.shapeContainer2.Size = new System.Drawing.Size(754, 81);
            this.shapeContainer2.TabIndex = 11;
            this.shapeContainer2.TabStop = false;
            // 
            // ledSyringe2
            // 
            this.ledSyringe2.BackColor = System.Drawing.Color.Transparent;
            this.ledSyringe2.FillColor = System.Drawing.Color.Red;
            this.ledSyringe2.FillGradientColor = System.Drawing.Color.Transparent;
            this.ledSyringe2.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ledSyringe2.Location = new System.Drawing.Point(730, 60);
            this.ledSyringe2.Name = "ledSyringe2";
            this.ledSyringe2.Size = new System.Drawing.Size(16, 16);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblFreq3);
            this.groupBox3.Controls.Add(this.lblCur3);
            this.groupBox3.Controls.Add(this.txtCurValue3);
            this.groupBox3.Controls.Add(this.lblMax3);
            this.groupBox3.Controls.Add(this.cmdDir3);
            this.groupBox3.Controls.Add(this.lblMin3);
            this.groupBox3.Controls.Add(this.tbrSyringe3);
            this.groupBox3.Controls.Add(this.shapeContainer4);
            this.groupBox3.Location = new System.Drawing.Point(12, 239);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(760, 100);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "SYRINGE003";
            // 
            // lblFreq3
            // 
            this.lblFreq3.AutoSize = true;
            this.lblFreq3.Location = new System.Drawing.Point(469, 45);
            this.lblFreq3.Name = "lblFreq3";
            this.lblFreq3.Size = new System.Drawing.Size(29, 13);
            this.lblFreq3.TabIndex = 10;
            this.lblFreq3.Text = "0 Hz";
            // 
            // lblCur3
            // 
            this.lblCur3.AutoSize = true;
            this.lblCur3.Location = new System.Drawing.Point(686, 25);
            this.lblCur3.Name = "lblCur3";
            this.lblCur3.Size = new System.Drawing.Size(40, 13);
            this.lblCur3.TabIndex = 10;
            this.lblCur3.Text = "µL/min";
            // 
            // txtCurValue3
            // 
            this.txtCurValue3.Location = new System.Drawing.Point(472, 22);
            this.txtCurValue3.Name = "txtCurValue3";
            this.txtCurValue3.Size = new System.Drawing.Size(208, 20);
            this.txtCurValue3.TabIndex = 9;
            this.txtCurValue3.Text = "0";
            this.txtCurValue3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCurValue3.TextChanged += new System.EventHandler(this.txtCurValue3_TextChanged);
            this.txtCurValue3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCurValue3_KeyDown);
            // 
            // lblMax3
            // 
            this.lblMax3.AutoSize = true;
            this.lblMax3.Location = new System.Drawing.Point(384, 67);
            this.lblMax3.Name = "lblMax3";
            this.lblMax3.Size = new System.Drawing.Size(43, 13);
            this.lblMax3.TabIndex = 10;
            this.lblMax3.Text = "lblMax3";
            // 
            // cmdDir3
            // 
            this.cmdDir3.Location = new System.Drawing.Point(472, 70);
            this.cmdDir3.Name = "cmdDir3";
            this.cmdDir3.Size = new System.Drawing.Size(64, 24);
            this.cmdDir3.TabIndex = 6;
            this.cmdDir3.Text = "OUT";
            this.cmdDir3.UseVisualStyleBackColor = true;
            this.cmdDir3.Click += new System.EventHandler(this.cmdDir3_Click);
            // 
            // lblMin3
            // 
            this.lblMin3.AutoSize = true;
            this.lblMin3.Location = new System.Drawing.Point(11, 67);
            this.lblMin3.Name = "lblMin3";
            this.lblMin3.Size = new System.Drawing.Size(64, 13);
            this.lblMin3.TabIndex = 9;
            this.lblMin3.Text = "0.00 µL/min";
            // 
            // tbrSyringe3
            // 
            this.tbrSyringe3.Location = new System.Drawing.Point(6, 19);
            this.tbrSyringe3.Maximum = 100;
            this.tbrSyringe3.Name = "tbrSyringe3";
            this.tbrSyringe3.Size = new System.Drawing.Size(408, 45);
            this.tbrSyringe3.TabIndex = 3;
            this.tbrSyringe3.ValueChanged += new System.EventHandler(this.tbrSyringe3_ValueChanged);
            // 
            // shapeContainer4
            // 
            this.shapeContainer4.Location = new System.Drawing.Point(3, 16);
            this.shapeContainer4.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer4.Name = "shapeContainer4";
            this.shapeContainer4.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ledSyringe3});
            this.shapeContainer4.Size = new System.Drawing.Size(754, 81);
            this.shapeContainer4.TabIndex = 11;
            this.shapeContainer4.TabStop = false;
            // 
            // ledSyringe3
            // 
            this.ledSyringe3.BackColor = System.Drawing.Color.Transparent;
            this.ledSyringe3.FillColor = System.Drawing.Color.Red;
            this.ledSyringe3.FillGradientColor = System.Drawing.Color.Transparent;
            this.ledSyringe3.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ledSyringe3.Location = new System.Drawing.Point(730, 60);
            this.ledSyringe3.Name = "ledSyringe3";
            this.ledSyringe3.Size = new System.Drawing.Size(16, 16);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblFreq4);
            this.groupBox4.Controls.Add(this.lblCur4);
            this.groupBox4.Controls.Add(this.txtCurValue4);
            this.groupBox4.Controls.Add(this.lblMax4);
            this.groupBox4.Controls.Add(this.cmdDir4);
            this.groupBox4.Controls.Add(this.lblMin4);
            this.groupBox4.Controls.Add(this.tbrSyringe4);
            this.groupBox4.Controls.Add(this.shapeContainer5);
            this.groupBox4.Location = new System.Drawing.Point(12, 345);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(760, 100);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "SYRINGE004";
            // 
            // lblFreq4
            // 
            this.lblFreq4.AutoSize = true;
            this.lblFreq4.Location = new System.Drawing.Point(469, 42);
            this.lblFreq4.Name = "lblFreq4";
            this.lblFreq4.Size = new System.Drawing.Size(29, 13);
            this.lblFreq4.TabIndex = 13;
            this.lblFreq4.Text = "0 Hz";
            // 
            // lblCur4
            // 
            this.lblCur4.AutoSize = true;
            this.lblCur4.Location = new System.Drawing.Point(686, 22);
            this.lblCur4.Name = "lblCur4";
            this.lblCur4.Size = new System.Drawing.Size(40, 13);
            this.lblCur4.TabIndex = 11;
            this.lblCur4.Text = "µL/min";
            // 
            // txtCurValue4
            // 
            this.txtCurValue4.Location = new System.Drawing.Point(472, 19);
            this.txtCurValue4.Name = "txtCurValue4";
            this.txtCurValue4.Size = new System.Drawing.Size(208, 20);
            this.txtCurValue4.TabIndex = 11;
            this.txtCurValue4.Text = "0";
            this.txtCurValue4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtCurValue4.TextChanged += new System.EventHandler(this.txtCurValue4_TextChanged);
            this.txtCurValue4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCurValue4_KeyDown);
            // 
            // lblMax4
            // 
            this.lblMax4.AutoSize = true;
            this.lblMax4.Location = new System.Drawing.Point(384, 67);
            this.lblMax4.Name = "lblMax4";
            this.lblMax4.Size = new System.Drawing.Size(43, 13);
            this.lblMax4.TabIndex = 12;
            this.lblMax4.Text = "lblMax4";
            // 
            // cmdDir4
            // 
            this.cmdDir4.Location = new System.Drawing.Point(472, 70);
            this.cmdDir4.Name = "cmdDir4";
            this.cmdDir4.Size = new System.Drawing.Size(64, 24);
            this.cmdDir4.TabIndex = 7;
            this.cmdDir4.Text = "OUT";
            this.cmdDir4.UseVisualStyleBackColor = true;
            this.cmdDir4.Click += new System.EventHandler(this.cmdDir4_Click);
            // 
            // lblMin4
            // 
            this.lblMin4.AutoSize = true;
            this.lblMin4.Location = new System.Drawing.Point(11, 67);
            this.lblMin4.Name = "lblMin4";
            this.lblMin4.Size = new System.Drawing.Size(64, 13);
            this.lblMin4.TabIndex = 11;
            this.lblMin4.Text = "0.00 µL/min";
            // 
            // tbrSyringe4
            // 
            this.tbrSyringe4.Location = new System.Drawing.Point(6, 19);
            this.tbrSyringe4.Maximum = 100;
            this.tbrSyringe4.Name = "tbrSyringe4";
            this.tbrSyringe4.Size = new System.Drawing.Size(408, 45);
            this.tbrSyringe4.TabIndex = 3;
            this.tbrSyringe4.ValueChanged += new System.EventHandler(this.tbrSyringe4_ValueChanged);
            // 
            // shapeContainer5
            // 
            this.shapeContainer5.Location = new System.Drawing.Point(3, 16);
            this.shapeContainer5.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer5.Name = "shapeContainer5";
            this.shapeContainer5.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ledSyringe4});
            this.shapeContainer5.Size = new System.Drawing.Size(754, 81);
            this.shapeContainer5.TabIndex = 14;
            this.shapeContainer5.TabStop = false;
            // 
            // ledSyringe4
            // 
            this.ledSyringe4.BackColor = System.Drawing.Color.Transparent;
            this.ledSyringe4.FillColor = System.Drawing.Color.Red;
            this.ledSyringe4.FillGradientColor = System.Drawing.Color.Transparent;
            this.ledSyringe4.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ledSyringe4.Location = new System.Drawing.Point(730, 60);
            this.ledSyringe4.Name = "ledSyringe4";
            this.ledSyringe4.Size = new System.Drawing.Size(16, 16);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.cmdSend);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.shapeContainer1);
            this.groupBox5.Location = new System.Drawing.Point(12, 451);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(759, 59);
            this.groupBox5.TabIndex = 8;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "LEGEND AND GENERAL CONTROLS";
            // 
            // cmdSend
            // 
            this.cmdSend.Enabled = false;
            this.cmdSend.Location = new System.Drawing.Point(550, 22);
            this.cmdSend.Name = "cmdSend";
            this.cmdSend.Size = new System.Drawing.Size(200, 24);
            this.cmdSend.TabIndex = 4;
            this.cmdSend.Text = "SEND STATE";
            this.cmdSend.UseVisualStyleBackColor = true;
            this.cmdSend.Click += new System.EventHandler(this.cmdSend_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(370, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "STATUS SUCCESSFULLY SENT";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "NEW STATUS NOT YET SENT";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "OFF STATUS SENT / 0 Hz";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(3, 16);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ovalShape3,
            this.ovalShape2,
            this.ovalShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(753, 40);
            this.shapeContainer1.TabIndex = 0;
            this.shapeContainer1.TabStop = false;
            // 
            // ovalShape3
            // 
            this.ovalShape3.BackColor = System.Drawing.Color.Transparent;
            this.ovalShape3.BorderColor = System.Drawing.Color.Black;
            this.ovalShape3.FillColor = System.Drawing.Color.Yellow;
            this.ovalShape3.FillGradientColor = System.Drawing.Color.Transparent;
            this.ovalShape3.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape3.Location = new System.Drawing.Point(350, 10);
            this.ovalShape3.Name = "ovalShape3";
            this.ovalShape3.Size = new System.Drawing.Size(16, 16);
            // 
            // ovalShape2
            // 
            this.ovalShape2.BackColor = System.Drawing.Color.Transparent;
            this.ovalShape2.BorderColor = System.Drawing.Color.Black;
            this.ovalShape2.FillColor = System.Drawing.Color.Red;
            this.ovalShape2.FillGradientColor = System.Drawing.Color.Transparent;
            this.ovalShape2.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape2.Location = new System.Drawing.Point(170, 10);
            this.ovalShape2.Name = "ovalShape2";
            this.ovalShape2.Size = new System.Drawing.Size(16, 16);
            // 
            // ovalShape1
            // 
            this.ovalShape1.BackColor = System.Drawing.Color.Transparent;
            this.ovalShape1.FillColor = System.Drawing.Color.Black;
            this.ovalShape1.FillGradientColor = System.Drawing.Color.Transparent;
            this.ovalShape1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ovalShape1.Location = new System.Drawing.Point(10, 10);
            this.ovalShape1.Name = "ovalShape1";
            this.ovalShape1.Size = new System.Drawing.Size(16, 16);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 611);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PRODUCT 762";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbrSyringe4)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fILEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oPENToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eDITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hELPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sYRINGESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cLOSEToolStripMenuItem;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.TrackBar tbrSyringe1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TrackBar tbrSyringe2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TrackBar tbrSyringe3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TrackBar tbrSyringe4;
        private System.Windows.Forms.ToolStripMenuItem aBOUTToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem sENDToolStripMenuItem;
        private Button cmdDir1;
        private Button cmdDir2;
        private Button cmdDir3;
        private Button cmdDir4;
        private Label lblMax1;
        private Label lblMin1;
        private Label lblMax2;
        private Label lblMax3;
        private Label lblMin3;
        private Label lblMax4;
        private Label lblMin4;
        private Label lblMin2;
        private TextBox txtCurValue1;
        private TextBox txtCurValue2;
        private TextBox txtCurValue3;
        private TextBox txtCurValue4;
        private Label lblCur1;
        private Label lblCur2;
        private Label lblCur3;
        private Label lblCur4;
        private Label lblFreq1;
        private Label lblFreq2;
        private Label lblFreq3;
        private Label lblFreq4;
        private GroupBox groupBox5;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ovalShape3;
        private Label label1;
        private Label label2;
        private Label label3;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ledSyringe1;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ledSyringe2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer4;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ledSyringe3;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer5;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ledSyringe4;
        private Button cmdSend;
        private ToolStripMenuItem rESCANBUSToolStripMenuItem;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem gLOBALSETTINGSToolStripMenuItem;

        
    }
}

