﻿using System.Windows.Forms;

namespace product762
{
    partial class frmSyringesSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdOk = new System.Windows.Forms.Button();
            this.lblDiameter = new System.Windows.Forms.Label();
            this.lblScrewMovmentPerRev = new System.Windows.Forms.Label();
            this.txtDiameter1 = new System.Windows.Forms.TextBox();
            this.txtDiameter2 = new System.Windows.Forms.TextBox();
            this.txtDiameter3 = new System.Windows.Forms.TextBox();
            this.txtDiameter4 = new System.Windows.Forms.TextBox();
            this.txtMovPerRev4 = new System.Windows.Forms.TextBox();
            this.txtMovPerRev3 = new System.Windows.Forms.TextBox();
            this.txtMovPerRev2 = new System.Windows.Forms.TextBox();
            this.txtMovPerRev1 = new System.Windows.Forms.TextBox();
            this.txtStepsPerRev4 = new System.Windows.Forms.TextBox();
            this.txtStepsPerRev3 = new System.Windows.Forms.TextBox();
            this.txtStepsPerRev2 = new System.Windows.Forms.TextBox();
            this.txtStepsPerRev1 = new System.Windows.Forms.TextBox();
            this.lblStepsPerRev = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmdOk
            // 
            this.cmdOk.Location = new System.Drawing.Point(498, 148);
            this.cmdOk.Name = "cmdOk";
            this.cmdOk.Size = new System.Drawing.Size(64, 24);
            this.cmdOk.TabIndex = 0;
            this.cmdOk.Text = "OK";
            this.cmdOk.UseVisualStyleBackColor = true;
            this.cmdOk.Click += new System.EventHandler(this.cmdOk_Click);
            // 
            // lblDiameter
            // 
            this.lblDiameter.AutoSize = true;
            this.lblDiameter.Location = new System.Drawing.Point(37, 9);
            this.lblDiameter.Name = "lblDiameter";
            this.lblDiameter.Size = new System.Drawing.Size(104, 13);
            this.lblDiameter.TabIndex = 2;
            this.lblDiameter.Text = "syringe diameter/mm";
            // 
            // lblScrewMovmentPerRev
            // 
            this.lblScrewMovmentPerRev.AutoSize = true;
            this.lblScrewMovmentPerRev.Location = new System.Drawing.Point(215, 9);
            this.lblScrewMovmentPerRev.Name = "lblScrewMovmentPerRev";
            this.lblScrewMovmentPerRev.Size = new System.Drawing.Size(169, 13);
            this.lblScrewMovmentPerRev.TabIndex = 3;
            this.lblScrewMovmentPerRev.Text = "screw movment per revolution/mm";
            // 
            // txtDiameter1
            // 
            this.txtDiameter1.Location = new System.Drawing.Point(40, 34);
            this.txtDiameter1.Name = "txtDiameter1";
            this.txtDiameter1.Size = new System.Drawing.Size(172, 20);
            this.txtDiameter1.TabIndex = 8;
            this.txtDiameter1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDiameter2
            // 
            this.txtDiameter2.Location = new System.Drawing.Point(40, 60);
            this.txtDiameter2.Name = "txtDiameter2";
            this.txtDiameter2.Size = new System.Drawing.Size(172, 20);
            this.txtDiameter2.TabIndex = 9;
            this.txtDiameter2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDiameter3
            // 
            this.txtDiameter3.Location = new System.Drawing.Point(40, 86);
            this.txtDiameter3.Name = "txtDiameter3";
            this.txtDiameter3.Size = new System.Drawing.Size(172, 20);
            this.txtDiameter3.TabIndex = 10;
            this.txtDiameter3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDiameter4
            // 
            this.txtDiameter4.Location = new System.Drawing.Point(40, 112);
            this.txtDiameter4.Name = "txtDiameter4";
            this.txtDiameter4.Size = new System.Drawing.Size(172, 20);
            this.txtDiameter4.TabIndex = 11;
            this.txtDiameter4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMovPerRev4
            // 
            this.txtMovPerRev4.Location = new System.Drawing.Point(218, 112);
            this.txtMovPerRev4.Name = "txtMovPerRev4";
            this.txtMovPerRev4.Size = new System.Drawing.Size(169, 20);
            this.txtMovPerRev4.TabIndex = 15;
            this.txtMovPerRev4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMovPerRev3
            // 
            this.txtMovPerRev3.Location = new System.Drawing.Point(218, 86);
            this.txtMovPerRev3.Name = "txtMovPerRev3";
            this.txtMovPerRev3.Size = new System.Drawing.Size(169, 20);
            this.txtMovPerRev3.TabIndex = 14;
            this.txtMovPerRev3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMovPerRev2
            // 
            this.txtMovPerRev2.Location = new System.Drawing.Point(218, 60);
            this.txtMovPerRev2.Name = "txtMovPerRev2";
            this.txtMovPerRev2.Size = new System.Drawing.Size(169, 20);
            this.txtMovPerRev2.TabIndex = 13;
            this.txtMovPerRev2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtMovPerRev1
            // 
            this.txtMovPerRev1.Location = new System.Drawing.Point(218, 34);
            this.txtMovPerRev1.Name = "txtMovPerRev1";
            this.txtMovPerRev1.Size = new System.Drawing.Size(169, 20);
            this.txtMovPerRev1.TabIndex = 12;
            this.txtMovPerRev1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtStepsPerRev4
            // 
            this.txtStepsPerRev4.Location = new System.Drawing.Point(393, 112);
            this.txtStepsPerRev4.Name = "txtStepsPerRev4";
            this.txtStepsPerRev4.Size = new System.Drawing.Size(169, 20);
            this.txtStepsPerRev4.TabIndex = 19;
            this.txtStepsPerRev4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtStepsPerRev3
            // 
            this.txtStepsPerRev3.Location = new System.Drawing.Point(393, 86);
            this.txtStepsPerRev3.Name = "txtStepsPerRev3";
            this.txtStepsPerRev3.Size = new System.Drawing.Size(169, 20);
            this.txtStepsPerRev3.TabIndex = 18;
            this.txtStepsPerRev3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtStepsPerRev2
            // 
            this.txtStepsPerRev2.Location = new System.Drawing.Point(393, 60);
            this.txtStepsPerRev2.Name = "txtStepsPerRev2";
            this.txtStepsPerRev2.Size = new System.Drawing.Size(169, 20);
            this.txtStepsPerRev2.TabIndex = 17;
            this.txtStepsPerRev2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtStepsPerRev1
            // 
            this.txtStepsPerRev1.Location = new System.Drawing.Point(393, 34);
            this.txtStepsPerRev1.Name = "txtStepsPerRev1";
            this.txtStepsPerRev1.Size = new System.Drawing.Size(169, 20);
            this.txtStepsPerRev1.TabIndex = 16;
            this.txtStepsPerRev1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblStepsPerRev
            // 
            this.lblStepsPerRev.AutoSize = true;
            this.lblStepsPerRev.Location = new System.Drawing.Point(390, 9);
            this.lblStepsPerRev.Name = "lblStepsPerRev";
            this.lblStepsPerRev.Size = new System.Drawing.Size(128, 13);
            this.lblStepsPerRev.TabIndex = 20;
            this.lblStepsPerRev.Text = "motor steps per revolution";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(9, 37);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(25, 13);
            this.lbl1.TabIndex = 21;
            this.lbl1.Text = "001";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(9, 63);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(25, 13);
            this.lbl2.TabIndex = 22;
            this.lbl2.Text = "002";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(9, 89);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(25, 13);
            this.lbl3.TabIndex = 23;
            this.lbl3.Text = "003";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(9, 115);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(25, 13);
            this.lbl4.TabIndex = 24;
            this.lbl4.Text = "004";
            // 
            // frmSyringesSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 186);
            this.ControlBox = false;
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lblStepsPerRev);
            this.Controls.Add(this.txtStepsPerRev4);
            this.Controls.Add(this.txtStepsPerRev3);
            this.Controls.Add(this.txtStepsPerRev2);
            this.Controls.Add(this.txtStepsPerRev1);
            this.Controls.Add(this.txtMovPerRev4);
            this.Controls.Add(this.txtMovPerRev3);
            this.Controls.Add(this.txtMovPerRev2);
            this.Controls.Add(this.txtMovPerRev1);
            this.Controls.Add(this.txtDiameter4);
            this.Controls.Add(this.txtDiameter3);
            this.Controls.Add(this.txtDiameter2);
            this.Controls.Add(this.txtDiameter1);
            this.Controls.Add(this.lblScrewMovmentPerRev);
            this.Controls.Add(this.lblDiameter);
            this.Controls.Add(this.cmdOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmSyringesSettings";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SYRINGE SETUP";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdOk;
        private System.Windows.Forms.Label lblDiameter;
        private System.Windows.Forms.Label lblScrewMovmentPerRev;
        private System.Windows.Forms.TextBox txtDiameter1;
        private System.Windows.Forms.TextBox txtDiameter2;
        private System.Windows.Forms.TextBox txtDiameter3;
        private System.Windows.Forms.TextBox txtDiameter4;
        private System.Windows.Forms.TextBox txtMovPerRev1;
        private System.Windows.Forms.TextBox txtMovPerRev2;
        private System.Windows.Forms.TextBox txtMovPerRev3;
        private System.Windows.Forms.TextBox txtMovPerRev4;
        private TextBox txtStepsPerRev4;
        private TextBox txtStepsPerRev3;
        private TextBox txtStepsPerRev2;
        private TextBox txtStepsPerRev1;
        private Label lblStepsPerRev;
        private Label lbl1;
        private Label lbl2;
        private Label lbl3;
        private Label lbl4;

    }
}