﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace product762
{
    public partial class frmSyringesSettings : Form
    {
        public double[] diameters = new double[4];
        public double[] movPerRev = new double[4];
        public int[] stepsPerRev = new int[4];

        // load and save application wide settings
        public void loadSettings()
        {
            this.diameters[0] = Properties.Settings.Default.diameter1;
            this.diameters[1] = Properties.Settings.Default.diameter2;
            this.diameters[2] = Properties.Settings.Default.diameter3;
            this.diameters[3] = Properties.Settings.Default.diameter4;
            this.movPerRev[0] = Properties.Settings.Default.movPerRev1;
            this.movPerRev[1] = Properties.Settings.Default.movPerRev2;
            this.movPerRev[2] = Properties.Settings.Default.movPerRev3;
            this.movPerRev[3] = Properties.Settings.Default.movPerRev4;
            this.stepsPerRev[0] = Properties.Settings.Default.stepsPerRev1;
            this.stepsPerRev[1] = Properties.Settings.Default.stepsPerRev2;
            this.stepsPerRev[2] = Properties.Settings.Default.stepsPerRev3;
            this.stepsPerRev[3] = Properties.Settings.Default.stepsPerRev4;
            this.doubleAndIntValuesToTextControls();
        }
        public void doubleAndIntValuesToTextControls()
        {
            TextBox[] txtDiameters = { this.txtDiameter1, this.txtDiameter2, this.txtDiameter3, this.txtDiameter4 };
            TextBox[] txtMovPerRev = { this.txtMovPerRev1, this.txtMovPerRev2, this.txtMovPerRev3, this.txtMovPerRev4 };
            TextBox[] txtStepsPerRev = { this.txtStepsPerRev1, this.txtStepsPerRev2, this.txtStepsPerRev3, this.txtStepsPerRev4 };
            for (uint i = 0; i < 4; i++)
            {
                txtDiameters[i].Text = diameters[i].ToString(new CultureInfo("en-US"));
                txtMovPerRev[i].Text = movPerRev[i].ToString(new CultureInfo("en-US"));
                txtStepsPerRev[i].Text = stepsPerRev[i].ToString(new CultureInfo("en-US"));
            }
        }
        public void saveSettings()
        {
            Properties.Settings.Default.diameter1 = this.diameters[0];
            Properties.Settings.Default.diameter2 = this.diameters[1];
            Properties.Settings.Default.diameter3 = this.diameters[2];
            Properties.Settings.Default.diameter4 = this.diameters[3];
            Properties.Settings.Default.movPerRev1 = this.movPerRev[0];
            Properties.Settings.Default.movPerRev2 = this.movPerRev[1];
            Properties.Settings.Default.movPerRev3 = this.movPerRev[2];
            Properties.Settings.Default.movPerRev4 = this.movPerRev[3];
            Properties.Settings.Default.stepsPerRev1 = this.stepsPerRev[0];
            Properties.Settings.Default.stepsPerRev2 = this.stepsPerRev[1];
            Properties.Settings.Default.stepsPerRev3 = this.stepsPerRev[2];
            Properties.Settings.Default.stepsPerRev4 = this.stepsPerRev[3];
            Properties.Settings.Default.Save();
        }
        // validate input and save it double arrays
        private bool validateInput()
        {
            if (System.Double.TryParse(txtDiameter1.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.diameters[0]) &&
                System.Double.TryParse(txtDiameter2.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.diameters[1]) &&
                System.Double.TryParse(txtDiameter3.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.diameters[2]) &&
                System.Double.TryParse(txtDiameter4.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.diameters[3]) &&
                System.Double.TryParse(txtMovPerRev1.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.movPerRev[0]) &&
                System.Double.TryParse(txtMovPerRev2.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.movPerRev[1]) &&
                System.Double.TryParse(txtMovPerRev3.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.movPerRev[2]) &&
                System.Double.TryParse(txtMovPerRev4.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.movPerRev[3]) &&
                System.Int32.TryParse(txtStepsPerRev1.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.stepsPerRev[0]) &&
                System.Int32.TryParse(txtStepsPerRev2.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.stepsPerRev[1]) &&
                System.Int32.TryParse(txtStepsPerRev3.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.stepsPerRev[2]) &&
                System.Int32.TryParse(txtStepsPerRev4.Text, NumberStyles.Number, new CultureInfo("en-US"), out this.stepsPerRev[3]) &&
                (diameters[0] >= Constants.minDiameter) && (diameters[0] <= Constants.maxDiameter) &&
                (diameters[1] >= Constants.minDiameter) && (diameters[0] <= Constants.maxDiameter) &&
                (diameters[2] >= Constants.minDiameter) && (diameters[0] <= Constants.maxDiameter) &&
                (diameters[3] >= Constants.minDiameter) && (diameters[0] <= Constants.maxDiameter) &&
                (movPerRev[0] >= Constants.minMovPerRev) && (movPerRev[0] <= Constants.maxMovPerRev) &&
                (movPerRev[1] >= Constants.minMovPerRev) && (movPerRev[0] <= Constants.maxMovPerRev) &&
                (movPerRev[2] >= Constants.minMovPerRev) && (movPerRev[0] <= Constants.maxMovPerRev) &&
                (movPerRev[3] >= Constants.minMovPerRev) && (movPerRev[0] <= Constants.maxMovPerRev) &&
                (stepsPerRev[0] >= Constants.minStepsPerRev) && (stepsPerRev[0] <= Constants.maxStepsPerRev) &&
                (stepsPerRev[1] >= Constants.minStepsPerRev) && (stepsPerRev[0] <= Constants.maxStepsPerRev) &&
                (stepsPerRev[2] >= Constants.minStepsPerRev) && (stepsPerRev[0] <= Constants.maxStepsPerRev) &&
                (stepsPerRev[3] >= Constants.minStepsPerRev) && (stepsPerRev[0] <= Constants.maxStepsPerRev))
                return true;
            else
                return false;
        }

        // ALL FORM DESIGNER EVENTS
        public frmSyringesSettings()
        {
            InitializeComponent();
        }
        public TextBox diameter1
        {
            get { return txtDiameter1; }
        }
        public TextBox diameter2
        {
            get { return txtDiameter2; }
        }
        public TextBox diameter3
        {
            get { return txtDiameter3; }
        }
        public TextBox diameter4
        {
            get { return txtDiameter4; }
        }
        private void cmdOk_Click(object sender, EventArgs e)
        {
            if (this.validateInput())
            {
                this.Close();
            }
            else
            {
                MessageBox.Show(String.Format(new CultureInfo("en-US"), Properties.Resources.errorInvalidSyringeValues, Constants.minDiameter, Constants.maxDiameter, Constants.minMovPerRev, Constants.maxMovPerRev, Constants.minStepsPerRev, Constants.maxStepsPerRev), "Invalid input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
